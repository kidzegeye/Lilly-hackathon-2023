function validate_patient() {
    var text1= $('#username').val();
    var text2= $('#password').val();
    console.log("Here")
      $.ajax({
                  url: "/login",
                  type: "POST",
                  data: {text1:text1,
                  text2:text2}
              }).done(function(response) {
                response =response.result;
                $.ajax({
                    url: "/profile",
                    type: "GET",
                }
                )});
    };