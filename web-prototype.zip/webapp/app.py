from flask import redirect, Flask, render_template, request
import csv

app = Flask(__name__)

cache = {}

def check_patient(username):
    with open('similarities.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        output = False
        for row in csv_reader:
            if username == row[1]:
                print("Username found")
                return True
        if output == False:
            return False
        
def patient_data(username):
    with open('similarities.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        output = False
        data = {
            'clinical_id':'',
            'sim': ''
        }
        result_data = []
        for row in csv_reader:
            if username == row[1]:
                data['clinicalID'] = row[2]
                data['Similarity'] = row[3]
                result_data.append(data)
        return result_data

@app.route('/')
def index():
    if cache != {}:
        if cache['username'] != '':
            error_msg_logout_message = "Successful logout"
            cache['username'] = ''
            return render_template('index.html', loginMessage=error_msg_logout_message)
        else:
            # print("Here")
            return render_template('index.html', loginMessage="Welcome to the Patient Portal")
    else:
        # cache['username'] = ''
        return render_template('index.html', loginMessage="Welcome to the Patient Portal")

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == "POST":
        un = request.form['username']
        cache['username'] = un
        pw = request.form['password']
        if un != pw:
            error_msg_invalid_cred = "Invalid credentials provided"
            return render_template("login.html", errorMessage = error_msg_invalid_cred)
        combine = check_patient(un)
        if combine == True:
            return redirect('/profile')
        else:
            error_msg_patient_404 = "Patient not found"
            return render_template('login.html', errorMessage = error_msg_patient_404)
    else:
        # print("GET")
        return render_template('login.html', errorMessage="Patient Login")
    
@app.route('/profile', methods=['GET','POST'])
def profile():
    if request.method == "GET":
        patient_details = patient_data(cache['username'])
        # print(patient_details)
        return render_template('profile.html', tableData = patient_details)